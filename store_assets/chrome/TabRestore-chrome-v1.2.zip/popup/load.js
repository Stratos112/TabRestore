document.getElementById('file-input').addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const warning = document.getElementById('warning');
    const display = document.getElementById('file-name-display');
    if (!file.name.endsWith('.txt')) {
        warning.style.display = 'block';
        if (display) display.textContent = 'No file selected';
        this.value = '';
        return;
    }
    warning.style.display = 'none';
    if (display) display.textContent = file.name;

    var reader = new FileReader();
    reader.onload = function (e) {
        const allLines = e.target.result.toString().split('\n');
        const firstFew = allLines.map(l => l.trim()).filter(l => l).slice(0, 3);
        const looksValid = firstFew.some(l => l.includes('.'));
        if (!looksValid) {
            document.getElementById('warning').style.display = 'block';
            return;
        }
        var links = [];
        allLines.forEach(line => {
            const cleanLine = line.trim();
            if (cleanLine) {
                const formattedUrl = cleanLine.startsWith('http') ? cleanLine : `https://${cleanLine}`;
                links.push(formattedUrl);
            }
        });
        if (links.length === 0) return;

        chrome.storage.local.get(['preserveCurrentTabs', 'removeDuplicates'], (s) => {
            const preserveCurrentTabs = s.preserveCurrentTabs !== false;
            const removeDuplicates = s.removeDuplicates !== false;
            chrome.tabs.query({ currentWindow: true }, existingTabs => {
                const existingUrls = new Set(existingTabs.map(t => t.url));

                let toOpen = removeDuplicates
                    ? [...new Set(links)].filter(url => !existingUrls.has(url))
                    : links;

                if (toOpen.length === 0 && !preserveCurrentTabs) return;

                if (preserveCurrentTabs) {
                    if (toOpen.length === 0) return;
                    const groupName = file.name.replace(/\.txt$/i, '');
                    Promise.all(toOpen.map(link => new Promise(res =>
                        chrome.tabs.create({ url: link }, tab => res(tab.id))
                    ))).then(tabIds => {
                        chrome.tabs.getCurrent(loadTab => chrome.tabs.remove(loadTab.id));
                        if (chrome.tabs.group) {
                            chrome.tabs.group({ tabIds }, groupId => {
                                chrome.tabGroups.update(groupId, { title: groupName });
                            });
                        }
                    });
                } else {
                    const existingIds = existingTabs.map(t => t.id);
                    toOpen.forEach(link => chrome.tabs.create({ url: link }));
                    chrome.tabs.remove(existingIds);
                }
            });
        });
    };
    reader.readAsText(file);
});
